from threading import Thread
from OralInteraction import OralInteraction
from Cliente import Cliente
from missingDrink import MissingDrink
import darwin_tcp.darwin as dw

OralInteraction = OralInteraction()
OralInteraction.setRedLedFunction(dw.set_led_head)
newClient = []
clientCount = 0
clients = []

speakThread = []
signals = []

def checkThreads():
    try:
        if speakThread.isAlive():
            signals['speaking'] = True
        else:
            signals['speaking'] = False
    except:
        signals['speaking'] = False

def launchGreet():
    global speakThread
    speakThread = Thread(target = OralInteraction.greet, args = ())
    speakThread.start()

def askPresentation():
    global newClient
    repeat = True
    while repeat:
        dw.set_led_head(dw.led_colors['GREEN'])
        OralInteraction.askForName()
        name = OralInteraction.listeningName(OralInteraction.captureAudio())
        while name == "":
            dw.set_led_head(dw.led_colors['GREEN'])
            OralInteraction.apologize()
            OralInteraction.askForName()
            name = OralInteraction.listeningName(OralInteraction.captureAudio())
        affirmate = True
        while affirmate:
            dw.set_led_head(dw.led_colors['GREEN'])
            OralInteraction.verifyName(name)
            affirmation = OralInteraction.affirmationCheck(OralInteraction.captureAudio())
            if affirmation == 0:
                affirmate = False
            if affirmation == 1:
                affirmate = False
                repeat = False
    newClient = Cliente(name,"","no esta listo")

def launchAskPresentation():
    global speakThread
    speakThread = Thread(target = askPresentation, args = ())
    speakThread.start()

def requestDrink():
    global newClient, clientCount, clients
    repeat = True
    while repeat:
        dw.set_led_head(dw.led_colors['GREEN'])
        OralInteraction.askForDrink()
        drink = OralInteraction.listeningDrink(OralInteraction.captureAudio())
        while drink == "":
            dw.set_led_head(dw.led_colors['GREEN'])
            OralInteraction.apologize()
            OralInteraction.askForDrink()
            drink = OralInteraction.listeningDrink(OralInteraction.captureAudio())
        affirmate = True
        while affirmate:
            dw.set_led_head(dw.led_colors['GREEN'])
            OralInteraction.verifyDrink(drink)
            affirmation = OralInteraction.affirmationCheck(OralInteraction.captureAudio())
            if affirmation == 0:
                affirmate = False
            if affirmation == 1:
                affirmate = False
                repeat = False
    newClient.cambiarPedido(drink)
    clients.append(newClient)
    print()
    clientCount+=1

def launchRequestDrink():
    global speakThread
    speakThread = Thread(target = requestDrink, args = ())
    speakThread.start()

def requestNewPerson():
    repeat = True
    while repeat:
        dw.set_led_head(dw.led_colors['GREEN'])
        OralInteraction.askForNewPerson()
        newPerson = OralInteraction.captureAudio()
        while newPerson == "":
            dw.set_led_head(dw.led_colors['GREEN'])
            OralInteraction.apologize()
            OralInteraction.askForNewPerson()
            newPerson = OralInteraction.captureAudio()

        affirmate = True
        while affirmate:
            dw.set_led_head(dw.led_colors['GREEN'])
            OralInteraction.verifyNewPerson(newPerson)
            affirmation = OralInteraction.affirmationCheck(OralInteraction.captureAudio())
            if affirmation == 0:
                affirmate = False
            if affirmation == 1:
                affirmate = False
                repeat = False

    newPersonBoolean = OralInteraction.affirmationCheck(newPerson) == 1
    signals['newPerson'] = newPersonBoolean

def launchRequestNewPerson():
    global speakThread
    speakThread = Thread(target = requestNewPerson, args = ())
    speakThread.start()

def listingRequest():
    global clients
    OralInteraction.listingRequest(clients)
    waitingBarman = False
    while not waitingBarman:
        waitingBarman = OralInteraction.waitingBarmanResponse()
    done = False
    takePhoto = True
    while takePhoto:
        while not done:
            done = missingDrink.takeBarPhoto()
        missingDrink.analyzeImage()
        clients = missingDrink.checkOrder()
        OralInteraction.listingMissingObjects(clients)
        verificationAccepted = OralInteraction.verifyMissingObject()
        if takePhoto:
            takePhoto = False
        else:
            OralInteraction.apologizeBarman()
            takePhoto = True
    reqAlternatives = True
    while reqAlternatives:
        OralInteraction.requestAlternatives()
        alternatives = OralInteraction.listeningAlternatives()
        alternativesAccepted = OralInteraction.verifyAlternatives(alternatives)
        if alternativesAccepted:
            reqAlternatives = False
        else:
            OralInteraction.apologizeAlternatives()
            reqAlternatives = True
    OralInteraction.waveBarman()

def launchListingRequest():
    global speakThread
    speakThread = Thread(target = listingRequest, args = ())
    speakThread.start()
